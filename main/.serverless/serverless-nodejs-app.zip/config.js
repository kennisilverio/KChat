
module.exports = {
    aws_table_name: 'Messages',
    aws_config: {
        region: 'us-east-1',
        endpoint: 'http://dynamodb.us-east-1.amazonaws.com',
        accessKeyId: 'AKIAIUHOQGMHYM3X5L7A',
        secretAccessKey: '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',
    },
}
